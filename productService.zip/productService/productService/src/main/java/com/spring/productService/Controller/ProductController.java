package com.spring.productService.Controller;

import com.spring.productService.entity.Product;
import com.spring.productService.repo.ProductRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/product")
public class ProductController {
    @Autowired
    private ProductRepo productRepo;

    @PostMapping("/addProduct")
    public Product addProduct(@RequestBody Product product){
        return productRepo.save(product);
    }

    @GetMapping("/getAllProducts")
    public List<Product> getAllProducts(){
        return productRepo.findAll();
    }
    @GetMapping("/getAllProducts/{id}")
    public ResponseEntity<Product> getAllProducts(@PathVariable long id){
        Product product= productRepo.findById(id)
                .orElseThrow(()->new RuntimeException("Product not found for Id"+id));
        return ResponseEntity.ok(product);
    }

}
