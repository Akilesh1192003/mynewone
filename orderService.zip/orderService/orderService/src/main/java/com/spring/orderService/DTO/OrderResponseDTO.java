package com.spring.orderService.DTO;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class OrderResponseDTO {

    private Long orderId;
    private Long productId;
    private int quantity;
    private double totalPrice;

    private String productName;
    private double productPrice;
}
