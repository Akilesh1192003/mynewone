package com.spring.orderService.Controller;

import com.spring.orderService.DTO.OrderResponseDTO;
import com.spring.orderService.DTO.ProductDTO;
import com.spring.orderService.entity.Order;
import com.spring.orderService.repo.OrderRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.List;

@RestController
@RequestMapping("/orders")
public class OrderController {

    @Autowired
    private OrderRepo orderRepo;

    @Autowired
    private WebClient.Builder webClientBuilder;

    @PostMapping("/placeOrder")
    public Mono<ResponseEntity<OrderResponseDTO>> placeOrder(@RequestBody Order order)
    {
      return webClientBuilder.build()
              .get().uri("http://localhost:8081/product/getAllProducts/"+ order.getProductId()).retrieve()
              .bodyToMono(ProductDTO.class).map(
                      productDTO -> {
                          OrderResponseDTO orderResponseDTO=new OrderResponseDTO();

                          orderResponseDTO.setProductId(order.getProductId());
                          orderResponseDTO.setQuantity(order.getQuantity());
                          orderResponseDTO.setProductName(productDTO.getName());
                          orderResponseDTO.setProductPrice(productDTO.getPrice());
                          orderResponseDTO.setTotalPrice(order.getQuantity() * productDTO.getPrice());
                          orderRepo.save(order);
                          orderResponseDTO.setOrderId(order.getId());
                          return ResponseEntity.ok(orderResponseDTO);
                      });
    }

    @GetMapping("/getAllOrder")
    public List<Order> getAllOrders()
    {
        return orderRepo.findAll();
    }
}
