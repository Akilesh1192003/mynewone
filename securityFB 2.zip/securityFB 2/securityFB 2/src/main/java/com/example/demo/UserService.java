package com.example.demo;

import com.example.demo.model.Users;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class UserService implements UserDetailsService {
    @Autowired
    private BCryptPasswordEncoder pe;

    @Autowired
    public UserRepo ur;

    public void registerUser(Users user){
        user.setPassword(pe.encode(user.getPassword()));
        ur.save(user);
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Users user= ur.findByUsername(username);
        if(user==null){
            throw new UsernameNotFoundException("Invalid UserName");
        }
        return User.withUsername(user.getUsername())
                .password(user.getPassword())
                .authorities(user.getRole().name()).build();
    }

    public boolean isUsernameFound(String username){
        return ur.countByUsername(username)>0;
    }
}
