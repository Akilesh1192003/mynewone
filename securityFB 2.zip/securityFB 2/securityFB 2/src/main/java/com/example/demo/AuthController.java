package com.example.demo;

import com.example.demo.model.Users;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class AuthController {

    @Autowired
    private UserService us;

    @GetMapping("/signin")
    public String login(){
         return "signin";
    }

    @GetMapping("/")
    public String home(){
       return "home";
    }

    @GetMapping("/reg")
    public String reg(Model model){
        model.addAttribute("users",new Users());
        return "reg";
    }

    @PostMapping("/reg")
    public String regP(@Valid @ModelAttribute("users")Users user, BindingResult result, Model model){
        if(result.hasErrors()){
            model.addAttribute("users",user);
            return "reg";
        }
        if(us.isUsernameFound(user.getUsername())){
            model.addAttribute("error","Username Already Exist");
            return "reg";
        }
       us.registerUser(user);
       return "redirect:/login";
    }

    @GetMapping("/adminhome")
    public String ah(Authentication authentication,Model model){
        String name=authentication.getName();
        model.addAttribute("name",name);
        return "/adminHome";
    }

    @GetMapping("/userhome")
    public String uh(Authentication authentication,Model model){
        String name=authentication.getName();
        model.addAttribute("name",name);
        return "/userHome";
    }

}
