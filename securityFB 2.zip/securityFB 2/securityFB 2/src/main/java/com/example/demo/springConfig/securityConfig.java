package com.example.demo.springConfig;

import com.example.demo.UserService;
import com.example.demo.model.Roles;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;

@Configuration
@EnableWebSecurity
public class securityConfig {
    @Autowired
    private UserService us;

    @Autowired
    private BCryptPasswordEncoder pe;


    @Bean
    public SecurityFilterChain secconfig(HttpSecurity http) throws Exception {
        http.authorizeHttpRequests(req->req
                .requestMatchers("/signin","/reg").anonymous()
                .requestMatchers("/adminhome").hasAuthority("ADMIN")
                .requestMatchers("/userhome").hasAuthority("USER")
                .anyRequest().authenticated())
                .formLogin(form->form
                        .loginPage("/signin")
                        .loginProcessingUrl("/process-login")
                        .successHandler(authenticationSuccessHandler())
                        //.defaultSuccessUrl("/",true)
                        .failureUrl("/signin?error=true"))
                .csrf(csrf->csrf.disable());

        return http.build();
    }
    @Bean
    public UserDetailsService inmem(){
        UserDetails user1= User.withUsername("user1")
                .password(pe.encode("pass1"))
                .build();
        UserDetails admin= User.withUsername("admin")
                .password(pe.encode("pass2"))
                .build();
        return new InMemoryUserDetailsManager(user1,admin);
    }

    @Bean
    public DaoAuthenticationProvider authP(){
      DaoAuthenticationProvider pr=new DaoAuthenticationProvider();
      pr.setUserDetailsService(us);
      pr.setPasswordEncoder(pe);
      return pr;
    }

    @Bean
    public AuthenticationSuccessHandler authenticationSuccessHandler(){
        return (request, response, authentication) -> {
            String role=authentication.getAuthorities().stream()
                    .map(GrantedAuthority::getAuthority)
                    .findAny().orElse("USER");
            if("ADMIN".equals(role)){
                response.sendRedirect("/adminhome");
            } else {
                response.sendRedirect("/userhome");
            }
        };
    }
}
