package com.example.demo.model;

public enum Roles {
    ADMIN,
    USER
}
