package com.config.configurationExample;

public class Laptop implements Computer{

    @Override
    public void compile(){
        System.out.println("In laptop Class");
    }
}
