package com.config.configurationExample;

import com.config.configurationExample.config.AppConfig;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

@SpringBootApplication
public class ConfigurationExampleApplication {

	public static void main(String[] args) {

		ApplicationContext context=new AnnotationConfigApplicationContext(AppConfig.class);
		 Desktop dt=context.getBean("com2",Desktop.class);
		 dt.compile();
		Desktop dt1=context.getBean("com2",Desktop.class);

		/*Alien al= context.getBean(Alien.class);
		al= new Alien(2,dt);
		System.out.println(al.getAge());
		al.getCom().compile();*/



		//SpringApplication.run(ConfigurationExampleApplication.class, args);
		//ApplicationContext context=new ClassPathXmlApplicationContext("spring.xml");

	}

}
