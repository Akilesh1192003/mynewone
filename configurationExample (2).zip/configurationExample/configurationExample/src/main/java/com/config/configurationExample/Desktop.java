package com.config.configurationExample;

public class Desktop implements Computer
{
    public Desktop()
    {
        System.out.println("In desktop constructor");
    }

    @Override
    public void compile()
    {
        System.out.println("In desktop class");
    }
}
