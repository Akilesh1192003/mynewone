package com.config.configurationExample.config;

import com.config.configurationExample.Alien;
import com.config.configurationExample.Computer;
import com.config.configurationExample.Desktop;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

@Configuration
@ComponentScan("")
public class AppConfig {

    @Bean(name = "com2")
    @Scope("prototype")
    public Desktop desktop(){
        return new Desktop();
    }
    @Bean
    public Alien alien(Computer com){
        Alien obj =new Alien();
        obj.setCom(com);
        return new Alien();
    }
}
