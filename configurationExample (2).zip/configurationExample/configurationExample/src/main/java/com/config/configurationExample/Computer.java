package com.config.configurationExample;

public interface Computer {
    void compile();
}
