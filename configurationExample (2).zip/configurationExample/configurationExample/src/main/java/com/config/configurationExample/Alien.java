package com.config.configurationExample;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;

public class Alien {

    @Value("21")
    public int age;
    @Autowired
    //@Qualifier("")
    public Computer com;//field injection

    public Alien(Computer com) {//constructor injection
        this.com = com;
    }

    public Alien() {
    }

    public Alien(int age, Computer com) {
        this.age = age;
        this.com = com;
    }

    public Computer getCom() {
        return com;
    }

    @Autowired
    public void setCom(Computer com) {//setter injection
        this.com = com;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
