package com.config.configurationExample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConfigurationExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
