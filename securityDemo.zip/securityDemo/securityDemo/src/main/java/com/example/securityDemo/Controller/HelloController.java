package com.example.securityDemo.Controller;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {
    @GetMapping("/hello")
    public String hello(HttpServletRequest request){
        return "Hello World "+request.getSession().getId();
    }
    @GetMapping("/home")
    public String home(){
        return "Home";
    }
    @GetMapping("/about")
    public String about(){
        return "About Us";
    }
}
